﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DeskMetrics;

namespace DeskMetricsDemoApp
{
    public partial class Form1 : Form
    {
        Watcher watcher = new Watcher();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            watcher.Start("your_app_id", "1.0");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            watcher.Stop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            watcher.TrackEvent("ButtonClick", "TrackMe");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            watcher.TrackCustomData("UserEmail", textBox1.Text);
        }
    }
}
