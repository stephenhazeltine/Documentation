package jdeskmetricsdemoapp;

import com.DeskMetrics.DeskMetrics;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import javax.swing.JButton;

import javax.swing.JFrame;

public class Main extends JFrame {
    public static void main(String[] args) throws IOException {
        Main frame = new Main();
        frame.setSize(new Dimension(200, 200));
        frame.setTitle("DeskMetrics DemoApp");

        final DeskMetrics deskmetrics = DeskMetrics.getInstance();
        String appID = "put_your_app_id_here";


        deskmetrics.start(appID, "0.5");

        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    deskmetrics.stop();
                    System.out.println("Application finished");
                } catch (IOException ex) {
                    System.out.println("Failed to finish the application correctly.");
                }
                System.exit(0);
            }
        });


        //add a button and a simple event tracking to it
        JButton button = new JButton();
        button.setText("Click me!");
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                deskmetrics.trackEvent("ButtonClick", "ClickMe");
            }
        });
        frame.add(button);

        frame.setVisible(true);
    }
}
